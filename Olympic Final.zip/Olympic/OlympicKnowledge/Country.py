import pandas as pd
from fpdf import FPDF
import requests
import os
import json

"""
  Try: 1. define my data Frame (from csv file)
       2. from df find  sport convert it as lower string
       3.  from df find team = country  convert as lower string
    
"""
def read_csv(file_path, country, sport):
    df = pd.read_csv(file_path)
    df['Sport'] = df['Sport'].str.strip().str.lower()
    df['Team'] = df['Team'].str.strip().str.lower()
    filtered_df = df[(df['Team'] == country.lower()) & (df['Sport'] == sport.lower())]
    return filtered_df

"""
   try: 1. Use flag api for relevent country flag
        2.Country code convert as upper.
   outcome: Country flag
"""

def download_flag(country_code):
    url = f"https://flagsapi.com/{country_code.upper()}/flat/64.png"
    flag_path = f"{country_code.upper()}_flag.png"
    try:
        response = requests.get(url)
        if response.status_code == 200 and 'image/png' in response.headers.get('Content-Type', ''):
            with open(flag_path, 'wb') as f:
                f.write(response.content)
            
            return flag_path
        else:
            print(f"Failed to download flag from {url}: Status code {response.status_code}")
    except requests.RequestException as e:
        print(f"Failed to download flag from {url}: {e}")
    
    return None

"""
  try : 1. Use website (restcountries) for geting country code
        2. Find out alpha-2 format .ex = Belgium as be
        3. use recountries json file. if website give an error for runtime..
  outcome: Country code for a specific country 
"""

def get_country_code(country_name):
    url = f"https://restcountries.com/v3.1/name/{country_name}"
    try:
        response = requests.get(url, timeout=10) 
        if response.status_code == 200:
            country_info = response.json()
            country_code = country_info[0]['cca2'].lower()
            return country_code
        else:
            print(f"API request failed with status code: {response.status_code}")
    except requests.RequestException as e:
        print(f"Failed to get country code.")

    try:
        with open('Country_code.json', 'r', encoding='utf-8') as file:
            country_codes = json.load(file)
            for country in country_codes:
                if country['name']['common'].lower() == country_name.lower():
                    return country['cca2']
            print(f"Country code for {country_name} not found in JSON file.")
    except FileNotFoundError:
        print("Country_code.json file not found.")
    
    return None
"""
  try: Styling pdf,heading, organizing all information , flag image  
"""
def create_pdf(country, sport, events, flag_image_path):
    class PDF(FPDF):
        def header(self):
            self.set_font('Arial', 'B', 16)
            country_name = country.title()
            sport_title = f"in {sport.upper()}"
            self.set_x(10)
            self.cell(self.get_string_width(country_name) + 10, 10, country_name)
            if flag_image_path and os.path.exists(flag_image_path):
                print(f"Adding flag image to PDF from {flag_image_path}")
                self.image(flag_image_path, x=self.get_x(), y=10, w=15, h=10)
                self.set_x(self.get_x() + 15)
            self.cell(0, 10, sport_title, ln=True)
            self.ln(20)

        def footer(self):
            self.set_y(-15)
            self.set_font('Arial', 'I', 8)
            self.cell(0, 10, f'Page {self.page_no()}', 0, 0, 'C')

        def chapter_title(self, year):
            self.set_font('Arial', 'B', 14)
            self.cell(0, 10, str(year), 0, 1, 'L')
            self.ln(4)

        def chapter_body(self, event, athlete, medal):
            self.set_font('Arial', '', 12)
            self.cell(0, 10, f'{event} - {athlete} - {medal}', 0, 1, 'L')
            self.ln(2)


    pdf = PDF()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=15)

    events = events.sort_values(by='Year')
    grouped = events.groupby('Year')
    for year, group in grouped:
        pdf.chapter_title(year)
        for _, row in group.iterrows():
            if row['Medal'] in ['Gold', 'Silver', 'Bronze']:
                pdf.chapter_body(row['Event'], row['Name'], row['Medal'])
    output_path = f"{country}_in_{sport}.pdf"
    pdf.output(output_path)
    print(f"PDF has been created successfully.")

"""
  try: Calling  all function 
  output: All information,flag in a pdf 
"""
def main():
    csv_file_path = 'all_athlete_games.csv'
    sport = "Karate"
    country = input("Enter the country name: ")

    events = read_csv(csv_file_path, country, sport)
    country_code = get_country_code(country)
    flag_image_path = None
    if country_code:
        flag_image_path = download_flag(country_code)
    if not flag_image_path:
        print("Flag could not be downloaded. Proceeding without flag image.")
    create_pdf(country, sport, events, flag_image_path)

if __name__ == "__main__":
    main()
