import pandas as pd
from fpdf import FPDF
import requests
import os
import threading
import json
"""
  Try: 1. define my data Frame (from csv file)
       2. from df find  year convert it as type int 
       3.  from df find team = country  convert as lower string
    
"""
def read_csv(file_path, year, sport):
    df = pd.read_csv(file_path)
    df['Sport'] = df['Sport'].str.strip().str.lower()
    df['Team'] = df['Team'].str.strip().str.lower()
    df['Year'] = df['Year'].astype(int)
    filtered_df = df[(df['Year'] == year) & (df['Sport'] == sport.lower())]
    return filtered_df

"""
   try: 1. Use flag api for relevent country flag
        2.Country code convert as upper.
   outcome: Country flag
"""

def download_flag(country_code):
    url = f"https://flagsapi.com/{country_code.upper()}/flat/64.png"
    flag_path = f"{country_code.upper()}_flag.png"
    try:
        response = requests.get(url)
        if response.status_code == 200 and 'image/png' in response.headers.get('Content-Type', ''):
            with open(flag_path, 'wb') as f:
                f.write(response.content)
            return flag_path
        else:
            print(f"Failed to download flag from {url}: Status code {response.status_code}")
    except requests.RequestException as e:
        print(f"Failed to download flag from {url}: {e}")
    
    return None

"""
  try : 1. Use website (restcountries) for geting country code
        2. Find out alpha-2 format .ex = Belgium as be
        3. use recountries json file. if website give an error for runtime..
  outcome: Country code for a specific country 
"""

def get_country_code(country_name):
    url = f"https://restcountries.com/v3.1/name/{country_name}"
    try:
        response = requests.get(url, timeout=10) 
        if response.status_code == 200:
            country_info = response.json()
            country_code = country_info[0]['cca2'].lower()
            return country_code
        else:
            print(f"API request failed with status code: {response.status_code}")
    except requests.RequestException as e:
        print(f"Failed to get country code {country_name}.")
    try:
        
        with open('Country_code.json', 'r', encoding='utf-8') as file:
            country_codes = json.load(file)
            for country in country_codes:
                if country['name']['common'].lower() == country_name.lower():
                    return country['cca2']
            print(f"Country code for {country_name} not found in JSON file.")
    except FileNotFoundError:
        print("Country_code.json file not found.")
    
    return None

"""
  try: Styling pdf,heading, organizing all information , flag image, year.  
"""
def create_pdf(year, sport, events, flag_paths):
    class PDF(FPDF):
        def header(self):
            self.set_font('Arial', 'B', 16)
            title = f"{year} {sport.upper()}"
            self.cell(0, 10, title, 0, 1, 'C')
            self.ln(10)

        def footer(self):
            self.set_y(-15)
            self.set_font('Arial', 'I', 8)
            self.cell(0, 10, f'Page {self.page_no()}', 0, 0, 'C')

        def chapter_title(self, title):
            self.set_font('Arial', 'B', 14)
            self.cell(0, 10, title, 0, 1, 'L')
            self.ln(4)

        def chapter_body(self, medal, athlete, event, flag_path):
            self.set_font('Arial', '', 12)
            medal_color = (255, 215, 0) if medal == "Gold" else (192, 192, 192) if medal == "Silver" else (205, 127, 50)
            self.set_fill_color(*medal_color)
            self.cell(30, 10, f'{medal}', 0, 0, 'C', fill=True)
            x_pos = self.get_x() + 2 
            y_pos = self.get_y()
            if flag_path and os.path.exists(flag_path):
                self.image(flag_path, x=x_pos, y=y_pos, w=15, h=10)
            self.cell(20)  
            self.cell(0, 10, f'{athlete} - {event}', 0, 1, 'L')
            self.ln(2)

    pdf = PDF()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=15)

    medals_order = ['Gold', 'Silver', 'Bronze']
    genders = {"Male": "Men's Events", "Female": "Women's Events"}

    for gender, gender_title in genders.items():
        gender_events = events[events['Gender'] == gender]
        if not gender_events.empty:
            pdf.chapter_title(gender_title)
            for medal in medals_order:
                group = gender_events[gender_events['Medal'].str.lower() == medal.lower()]
                if not group.empty:
                    pdf.set_font('Arial', 'B', 14)
                    pdf.cell(0, 10, medal.title(), 0, 1, 'L')
                    pdf.ln(4)
                    for _, row in group.iterrows():
                        flag_path = flag_paths.get(row['Team'].strip().lower(), None)
                        pdf.chapter_body(row['Medal'], row['Name'], row['Event'], flag_path)

    output_path = f"Olympics_{year}_{sport}.pdf"
    pdf.output(output_path)
    print(f"PDF has been created successfully.")

"""
  try: Calling  all function 
  output: All information,flag in a pdf 
"""

def main():
    csv_file_path = 'Year Winners.csv'
    year = int(input("Enter the year: "))
    sport = "Karate"

    events = read_csv(csv_file_path, year, sport)
    medal_events = events[events['Medal'].isin(['Gold', 'Silver', 'Bronze'])]
    unique_countries = medal_events['Team'].unique()
    flag_paths = {}

    def download_and_store_flag(country):
        country_code = get_country_code(country)
        if country_code:
            flag_path = download_flag(country_code)
            if flag_path:
                flag_paths[country] = flag_path

    for country in unique_countries:
        download_and_store_flag(country)  

    create_pdf(year, sport, medal_events, flag_paths)

if __name__ == "__main__":
    main()
