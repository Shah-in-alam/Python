## This the Final Project of my Scripting Course:
## Overview
    This project involves creating a set of endpoints that provide detailed information about Olympic Knowledge about (KARATE), 
    countries, years, and athletes. The data will be organized and presented in various formats, including general descriptions, 
    sorted lists, and detailed profiles. Additionally, the project will generate a PDF document summarizing the information.
## Endpoints =>

### 1. General
- **Description**: Provides all general information about the sport, including a description, picture, and equipment.
- **Details**: 
  - Description of the sport
  - Image representing the sport
  - List of required equipment

### 2. Country
- **Description**: Shows all medalists from a given country, sorted by year.
- **Details**:
  - Country flag
  - List of medalists with their respective years and medal types (gold, silver, bronze)

### 3. Year
- **Description**: Shows all medalists (athletes and their country) from a given year, categorized by medal.
- **Range**: If the user specifies a range of years, display the medalists for each year within the range.
- **Details**:
  - Year-wise categorization of medalists
  - Medal type categorization

### 4. Athlete
- **Description**: Shows all information and a picture of a given athlete.
- **Details**:
  - Athlete's picture
  - Detailed profile including name, country, and biography
  - List of Olympic medals they've won
  - If the athlete is not found, display a message indicating the athlete is not found

## PDF Generation
- **Structure**:
  - PSC (Professional Sports Council):
    - **Text**: Description and additional information
    - **Table**: Tabular representation of the data

## License
 This project is licensed under the MIT License - see the LICENSE  file for details.
