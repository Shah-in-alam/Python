# Function to read the README file
from setuptools import setup, find_packages
# def readme():
#     with open('README.md') as f:
#         return f.read()

setup(
    name='OlympicKnowledge', 
    version='0.1',
    description='A pdf generating Olympic Knowledge',
    long_description='file: README.md',  
    long_description_content_type='text/markdown',  
    author='Mohammad Shahin Alam',
    license='MIT',
    packages=find_packages(include=['OlympicKnowledge']),
    install_requires=[
        'requests',
        'reportlib',
        'bs4',
        'pandas',
        'datetime',
        'fpdf',
        'urllib.parse'
    ],
)